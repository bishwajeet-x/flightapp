package com.fbs.flight.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fbs.flight.entity.FlightSchedule;

public interface FlightScheduleRepo extends JpaRepository<FlightSchedule, Long> {

	public Optional<List<FlightSchedule>> findByStatus(int status);
	public Optional<FlightSchedule> findByFlightId(long flightId);
}
