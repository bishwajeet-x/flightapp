package com.fbs.airline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.fbs.airline.entity.Airline;
import com.fbs.airline.service.AirlineService;
import com.fbs.common.model.DefaultResponse;

//@RestController
//@RequestMapping("/airline")
public class AirlineRest {
	
	@Autowired private AirlineService service;
	
	//@GetMapping("/")
	public DefaultResponse fetchAllAirlines() {
		System.out.println("Inside fetchAllAirlines");
		return service.fetchAllAirlines();
	}
	
	//@GetMapping("/{id}")
	public DefaultResponse fetchAirlinesById(@PathVariable("id") long airlineId) {
		System.out.println("Inside fetchAirlinesById "+airlineId);
		return service.fetchAirlineById(airlineId);
	}
	
	//@GetMapping("/status/{id}")
	public DefaultResponse fetchAirlinesByStatus(@PathVariable("id") int statusId) {
		System.out.println("Inside fetchAirlinesByStatus "+ statusId);
		return service.fetchAirlinesByStatus(statusId);
	}
	
	//@PostMapping("/")
	public DefaultResponse createAirline(@RequestBody Airline airline) {
		System.out.println("Inside createAirline "+airline.toString());
		return service.createAirline(airline);
	}
	
	//@PostMapping("/edit")
	public DefaultResponse editAirline(@RequestBody Airline airline) {
		System.out.println("Inside editAirline "+airline.toString());
		return service.editAirline(airline);
	}
	
	//@PostMapping("/status/{airlineId}/{statusId}")
	public DefaultResponse changeAirlineStatus(@PathVariable("airlineId") long airlineId, @PathVariable("statusId") int statusId) {
		System.out.println("Inside changeAirlineStatus "+airlineId+" status id "+statusId);
		return service.changeAirlineStatus(airlineId, statusId);
	}

}
