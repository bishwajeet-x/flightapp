package com.fbs.flight.service;

import com.fbs.common.model.DefaultResponse;
import com.fbs.flight.dto.FlightScheduleDto;
import com.fbs.flight.entity.FlightSchedule;
import com.fbs.ticket.dto.SearchTicketParams;

public interface FlightScheduleService {

	public DefaultResponse fetchAllFlights();
	public DefaultResponse fetchFlightsByStatus(int status);
	public DefaultResponse fetchFlightById(long airlineId);
	public DefaultResponse changeFlightStatus(long airlineId, int status);
	public DefaultResponse createFlight(FlightScheduleDto flightSchedule);
	public DefaultResponse editFlight(FlightScheduleDto flight);
	public DefaultResponse searchFlight(SearchTicketParams params);
}
