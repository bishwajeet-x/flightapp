package com.fbs.airline.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fbs.airline.entity.Airline;
import com.fbs.airline.repo.AirlineRepo;
import com.fbs.airline.repo.AirlineStatusRepo;
import com.fbs.common.exception.NotFoundException;
import com.fbs.common.model.DefaultResponse;

@Service
public class AirlineServiceImpl implements AirlineService {
	
	@Autowired private AirlineRepo airlineRepo;
	@Autowired private AirlineStatusRepo statusRepo;

	@Override
	public DefaultResponse fetchAllAirlines() {
		List airlines = airlineRepo.findAll();
		return new DefaultResponse(true, "Airlines successfully fetched", airlines);
	}

	@Override
	public DefaultResponse fetchAirlinesByStatus(int status) {
		Optional<List<Airline>> airlines = airlineRepo.findByAirlineStatusId(status);
		if(airlines.isEmpty()) {
			throw new NotFoundException("No airlines with status "+status+" was found in the DB.");
		}
		return new DefaultResponse(true, "Airlines successfully fetched", airlines.get());
	}

	@Override
	public DefaultResponse fetchAirlineById(long airlineId) {
		Optional airline = airlineRepo.findByAirlineId(airlineId);
		if(airline.isEmpty()) {
			throw new NotFoundException("Airline id "+airlineId+" was not found in the DB");
		}
		return new DefaultResponse(true, "Airline successfully fetched", airline.get());
	}

	@Override
	public DefaultResponse changeAirlineStatus(long airlineId, int status) {
		DefaultResponse existing = fetchAirlineById(airlineId);
		if(!existing.isStatus()) {
			throw new NotFoundException("Airline id "+airlineId+" was not found in the DB");
		}
		Airline airline = (Airline) existing.getData();
		airline.setAirlineStatus(statusRepo.findById(status).get());
		return persistAirline(airline, "Airline status changed to "+status);
	}

	@Override
	public DefaultResponse createAirline(Airline airline) {
		airline.setAirlineStatus(statusRepo.findById(101).get());
		return persistAirline(airline, "Airline saved successfully");
	}

	@Override
	public DefaultResponse editAirline(Airline airline) {
		DefaultResponse existing = fetchAirlineById(airline.getAirlineId());
		if(!existing.isStatus()) {
			throw new NotFoundException("Airline id "+airline.getAirlineId()+" was not found in the DB");
		}
		Airline response = (Airline) existing.getData();
		response.setAirlineName(airline.getAirlineName());
		response.setAirlineStatus(statusRepo.findById(airline.getAirlineStatus().getId()).get());
		return persistAirline(response, "Airline edited successfully");
	}
	
	public DefaultResponse persistAirline(Airline existing, String msg) {
		Airline response = null;
		try {
			response = airlineRepo.save(existing);
			return new DefaultResponse(true, msg, response);
		} catch(Exception e) {
			return new DefaultResponse(false, e.getMessage(), response);
		}
	}

}
