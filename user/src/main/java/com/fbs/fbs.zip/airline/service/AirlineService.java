package com.fbs.airline.service;

import com.fbs.airline.entity.Airline;
import com.fbs.common.model.DefaultResponse;

public interface AirlineService {
	
	public DefaultResponse fetchAllAirlines();
	public DefaultResponse fetchAirlinesByStatus(int status);
	public DefaultResponse fetchAirlineById(long airlineId);
	public DefaultResponse changeAirlineStatus(long airlineId, int status);
	public DefaultResponse createAirline(Airline airline);
	public DefaultResponse editAirline(Airline airline);

}
