package com.fbs.auth.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fbs.auth.entity.Role;

public interface RoleRepo extends JpaRepository<Role, Long> {
	Role findByName(String rolename);
}
	